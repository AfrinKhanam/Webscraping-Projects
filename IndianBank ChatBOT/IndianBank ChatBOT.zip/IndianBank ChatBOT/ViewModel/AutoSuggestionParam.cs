﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace IndianBank_ChatBOT.ViewModel
{
    public class AutoSuggestionParam
    {
        public string Query { get; set; }
    }
}
