﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace IndianBank_ChatBOT.Models
{
    public class VisitorsByMonthViewModel
    {
        public int DayNumber { get; set; }
        public string MonthText { get; set; }
        public int Visits { get; set; }
    }
}
