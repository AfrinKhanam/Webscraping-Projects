﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace IndianBank_ChatBOT.Models
{
    public enum ResonseFeedback
    {
        ThumbsUp = 1,
        ThumbsDown = -1
    }
}
