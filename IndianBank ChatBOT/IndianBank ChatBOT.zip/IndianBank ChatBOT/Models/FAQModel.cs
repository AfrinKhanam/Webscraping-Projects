﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace IndianBank_ChatBOT.Models
{
    public class FAQModel
    {
        public string question { get; set; }
        public string confidence { get; set; }
        public string response { get; set; }
    }
}
