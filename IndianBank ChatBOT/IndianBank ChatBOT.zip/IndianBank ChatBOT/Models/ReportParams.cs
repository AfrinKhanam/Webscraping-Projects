﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace IndianBank_ChatBOT.Models
{
    public class ReportParams
    {
        public string From { get; set; }
        public string To { get; set; }
    }
}
